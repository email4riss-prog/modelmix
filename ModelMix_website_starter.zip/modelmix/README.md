# ModelMix

Responsive multi-AI debate room starter.

## Deploy on Render
- Create a Web Service connected to this repository.
- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Root directory: leave blank.
- Add API keys under Environment: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, and/or `GEMINI_API_KEY`.

Optional model overrides: `OPENAI_MODEL`, `ANTHROPIC_MODEL`, `GEMINI_MODEL`.

API keys must stay in the hosting provider's private environment settings, never in GitHub. API usage may cost money. This first version gathers parallel AI answers; moderator synthesis and live voice debate are not yet implemented.
