
const express=require('express'),path=require('path');
const app=express(); app.use(express.json()); app.use(express.static(path.join(__dirname,'public')));
const PORT=process.env.PORT||3000;
async function provider(name,prompt){
 const key=process.env[name+'_API_KEY']; if(!key) throw Error(name+' API key is not configured in hosting settings.');
 if(name==='OPENAI'){
  const r=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{Authorization:'Bearer '+key,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:'You are a thoughtful debate participant. Give reasons, identify assumptions, and respectfully challenge weak arguments.'},{role:'user',content:prompt}]})});
  const d=await r.json();if(!r.ok)throw Error(d.error?.message||'OpenAI request failed');return d.choices?.[0]?.message?.content||'No response';
 }
 if(name==='ANTHROPIC'){
  const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'x-api-key':key,'anthropic-version':'2023-06-01','content-type':'application/json'},body:JSON.stringify({model:process.env.ANTHROPIC_MODEL||'claude-3-5-haiku-latest',max_tokens:900,messages:[{role:'user',content:prompt}]})});
  const d=await r.json();if(!r.ok)throw Error(d.error?.message||'Claude request failed');return (d.content||[]).map(x=>x.text||'').join('\\n');
 }
 const model=process.env.GEMINI_MODEL||'gemini-2.0-flash';
 const r=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent?key='+encodeURIComponent(key),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});
 const d=await r.json();if(!r.ok)throw Error(d.error?.message||'Gemini request failed');return d.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('\\n')||'No response';
}
app.post('/api/debate',async(req,res)=>{
 const q=String(req.body.question||'').trim(),m=req.body.models||{};if(!q)return res.status(400).json({error:'Enter a question.'});
 const selected=[['OPENAI',m.openai],['ANTHROPIC',m.anthropic],['GEMINI',m.gemini]].filter(x=>x[1]);
 if(!selected.length)return res.status(400).json({error:'Choose at least one AI.'});
 const results=await Promise.all(selected.map(async([name])=>{try{return{name:name==='ANTHROPIC'?'Claude':name==='OPENAI'?'OpenAI':'Gemini',text:await provider(name,q)}}catch(e){return{name,text:'Unavailable: '+e.message}}}));
 res.json({results});
});
app.get('*',(_,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log('ModelMix listening on '+PORT));
